import React, { useState } from "react";

import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";

// Login Component

const Login1 = ({ setIsAuthenticated }) => {

  const [email, setEmail] = useState("");

  const [password, setPassword] = useState("");

  const handleLogin = (e) => {

    e.preventDefault();

    // Simulate authentication logic (you'd replace this with an API call)

    if (email === "user@example.com" && password === "password") {

      setIsAuthenticated(true);

    } else {

      alert("Invalid credentials");

    }

  };

  return (
<div>
<h2>Login</h2>
<form onSubmit={handleLogin}>
<input

          type="email"

          placeholder="Email"

          value={email}

          onChange={(e) => setEmail(e.target.value)}

        />
<input

          type="password"

          placeholder="Password"

          value={password}

          onChange={(e) => setPassword(e.target.value)}

        />
<button type="submit">Login</button>
</form>
</div>

  );

};

// Home Component (Protected Route)

const Home = () => {

  return <h2>Welcome to the Home Page! You are logged in.</h2>;

};

// Protected Route Component

const ProtectedRoute = ({ isAuthenticated, children }) => {

  return isAuthenticated ? children : <h2>You need to log in to view this page</h2>;

};

const App1 = () => {

  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
<Router>
<nav>
<Link to="/">Home</Link>

        {isAuthenticated ? (
<button onClick={() => setIsAuthenticated(false)}>Logout</button>

        ) : (
<Link to="/login">Login</Link>

        )}
</nav>
<Routes>
<Route path="/" element={<h2>Welcome! Please log in to view the content.</h2>} />
<Route

          path="/login"

          element={<Login1 setIsAuthenticated={setIsAuthenticated} />}

        />
<Route

          path="/home"

          element={
<ProtectedRoute isAuthenticated={isAuthenticated}>
<Home />
</ProtectedRoute>

          }

        />
</Routes>
</Router>

  );

};

export default App1; 