import React from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
// import './Header.css'; // Create this file to style your header

const Header = () => {
  const navigate= useNavigate();
  // const [modal, setModal] = useState(false);

  const handleCart = (e) =>{
    e.preventDefault();
    navigate('/Cart');
  }
//   const logout=()=> {
//     // localStorage.clear();
//     navigate('/Login');
// }
const logout=()=> {
  localStorage.clear();
  window.location.href = '/';
}
  return (
    <header className="header">
      <div><h1>Shop now on Skin Cart</h1></div>
      <div><button onClick={handleCart}>Cart</button></div>
      <div><button onClick={logout}>Logout</button>
      </div>
    </header>
  );
};

export default Header;
