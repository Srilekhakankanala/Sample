// import React, { useEffect, useState } from 'react';
// // import { useCart } from './CartContext';
// import { useDispatch, useSelector } from "react-redux";
//  // Import the actions

// import axios from 'axios';

// const ProductList = () => {
//  const [products, setProducts] =useState([])
// //  const { addToCart } = useCart(); 
//  const dispatch = useDispatch();
//  const cartItems = useSelector((state) => state.cart.items); // Get the items in the cart

//  useEffect(() => {
//   fetch('Product.json')
//     .then((response) => response.json())
//     .then((data) => {
//       setProducts(data);
//       console.log(data);
//     })
//     .catch(error=>{
//       console.log("Error fetching data:", error);
//     })
// }, []);

// const handleAddToCart = (product) => {
//   dispatch(addToCart(product)); // Dispatch addToCart action
// };

// const handleRemoveFromCart = (product) => {
//   dispatch(removeFromCart(product)); // Dispatch removeFromCart action
// };

// // Check if the product is in the cart
// const isProductInCart = (productId) => {
//   return cartItems.some((item) => item.id === productId);
// };

 
//  const [editingProduct, setEditingProduct] = useState(null);
//  const [isDialogOpen, setIsDialogOpen] = useState(false);

//  const handleEditClick = (product) => {
//    setEditingProduct(product);
//    setIsDialogOpen(true);
//  };

//  const closeDialog = () => {
//    setIsDialogOpen(false);
//    setEditingProduct(null);
//  };

//  const handleSave = (updatedProduct) => {
//    const updatedProducts = products.map((product) =>
// product.id === updatedProduct.id ? updatedProduct : product
//    );
//    setProducts(updatedProducts);
//    closeDialog();
//  };
//  const handleDeleteProduct = (id) => {
//   const filteredProducts = products.filter((product) => product.id !== id);
//   setProducts(filteredProducts);
// };


//  return (
//   <div>
//     <button onClick={()=>handleEditClick(products)}>Add Product</button>
//   {/* <button onClick={handleAdd}>Add</button> */}
//    <div className="product-list" >
//           {products.map((product) => (
//             <div key={product.id} className="product-card">
              
//               <img src={product.image_link} alt={product.name} />
//               <h2>{product.name}</h2>
//               {/* <h3>{product.description}</h3> */}
//               <p><strong>Price: ₹{product.price}</strong></p>
//               <button onClick={() => addToCart(product)}>Add to Cart</button><br></br>
//               <button onClick={() => handleEditClick(product)}>Edit</button><br></br>
//               <button onClick={() => handleDeleteProduct(product.id)}>Delete Product</button><br></br>
//               {isProductInCart(product.id) ? (
//                   <button
//                     className="btn btn-danger w-100"
//                     onClick={() => handleRemoveFromCart(product)}
//                   >
//                     Remove from Cart
//                   </button>
//                 ) : (
//                   <button
//                     className="btn btn-primary w-100"
//                     onClick={() => handleAddToCart(product)}
//                   >
//                     Add to Cart
//                   </button>
//                 )}
//             </div>
//             ))}
//        {/* Edit Product Dialog */}
//        {isDialogOpen && editingProduct && (
//   <EditProductDialog
//            product={editingProduct}
//            onClose={closeDialog}
//            onSave={handleSave}
//          />
//        )}
//   </div>
//   </div>
//    );
// };
// const EditProductDialog = ({ product, onClose, onSave }) => {
//  const [editedProduct, setEditedProduct] = useState({ ...product });
//  // Handle input changes
//  const handleChange = (e) => {
//    const { name, value } = e.target;
//    setEditedProduct({
//      ...editedProduct,
//      [name]: value,
//    });
//  };
//  // Handle form submit
//  const handleSubmit = (e) => {
//    e.preventDefault();
//    onSave(editedProduct);
//    console.log(editedProduct)
//  };
//  return (
// <div className="dialog">
// <div className="dialog-content">
// <h3>Product Details</h3><br></br>
// <form onSubmit={handleSubmit}>

// <div>
// <label>Product Id:</label>
// <input
//              type="text"
//              name="id"
//              placeholder='enter id of product'
//              value={editedProduct.id}
//              onChange={handleChange}
//            />
// </div>
// <br></br>
// <div>
// <label>Name:</label>
// <input
//              type="text"
//              name="name"
//              placeholder='enter name of product'
//              value={editedProduct.name}
//              onChange={handleChange}
//            />
// </div><br></br>
// <div>
// <label>Price:</label>
// <input
//              type="number"
//              name="price"
//              placeholder='please enter price'
//              value={editedProduct.price}
//              onChange={handleChange}
//            />
// </div><br></br>
// <div>
// <label>Image_link:</label>
// <input
//              type="text"
//              name="image_link"
//              placeholder='please enter image link '
//              value={editedProduct.image_link}
//              onChange={handleChange}
//            />
// </div><br></br>
// <div>
// <label>Description:</label>
// <input
//              type="text"
//              name="name"
//              placeholder='enter description'
//              value={editedProduct.description}
//              onChange={handleChange}
//            />
// </div><br></br>
// <table>
//   <tr>
//     <td><button type="submit">Save</button></td>
//     <td><button type="button" onClick={onClose}>Cancel</button></td>
//   </tr>
// </table>
// </form>
// </div>
// </div>
//  );
// };


// export default ProductList;