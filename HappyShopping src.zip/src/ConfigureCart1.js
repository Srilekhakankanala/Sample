import Cart from "./Cart";
import { CartProvider, useCart } from "./CartContext";
import Footer from "./Component/Footer";
import Header from "./Component/Header";
import Checkout from "./pages/Checkout";


export default function ConfigureCart1(){
    console.log("entered to provide list ")
   
return(
    <div>
        <Header/>
        <CartProvider>
            <Cart/>
           
        </CartProvider>
        <Footer/>     
    </div>
)
}
