import React from 'react';
import { useSelector } from 'react-redux';

const Checkout = () => {
  const cart = useSelector(state => state.cart);
  const total = cart.reduce((acc, product) => acc + product.price, 0);

  const handleCheckout = () => {
    alert('Order placed successfully!');
  };

  return (
    <div>
      <h1>Checkout</h1>
      <div>
        {cart.map(product => (
          <div key={product.id}>
            <h3>{product.name}</h3>
            <p>${product.price}</p>
          </div>
        ))}
        <h2>Total: ${total}</h2>
        <button onClick={handleCheckout}>Place Order</button>
      </div>
    </div>
  );
};

export default Checkout;
