// import "./styles.css";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import SignIn from "./SignIn";

export default function Register() {
  const [values, setValues] = useState({
    Name: "",
    email: "",
    password:""
  });
  const navigate = useNavigate();
  // const [register,setRegister]=useState([])
  
  const handleInputChange = (event) => {
    event.preventDefault();
    const {name, value } = event.target;
    setValues((values) => ({...values, [name]: value  }));
    console.log(values)
  };

  const [submitted, setSubmitted] = useState(false);
  const [valid, setValid] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (values.Name && values.email && values.password) {
      setValid(true);
      <SignIn setValues={setValues}/>
      navigate('/Login');
      // console.log(setValues)
    }
    setSubmitted(true);
  };

  return (
    <div className="register-container">
        <h1>Welcome Happy Shopping</h1>
      <form className="register-form" onSubmit={handleSubmit}>
        {submitted && valid && (
          <div>
            <h2 >
              {" "}
              Hi {values.Name}{" "}
            </h2>
            <div> Your registration is successful! </div>
            <button type="submit">Login</button>
          </div>
        )}
        {!valid && (
          <input
            class="form-field"
            type="text"
            placeholder="User Name"
            name="Name"
            value={values.Name}
            onChange={handleInputChange}
          />
        )}

        {submitted && !values.Name && (
          <span id="first-name-error">Please enter User name</span>
        )}

        {!valid && (
          <input
            class="form-field"
            type="email"
            placeholder="Email"
            name="email"
            value={values.email}
            onChange={handleInputChange}
          />
        )}

        {submitted && !values.email && (
          <span id="email-error">Please enter an email address</span>
        )}
        {!valid && (
          <input
            class="form-field"
            type="password"
            placeholder="Password"
            name="password"
            value={values.password}
            onChange={handleInputChange}
          />
        )}

        {submitted && !values.password && (
          <span id="password-error">Please enter password</span>
        )}

        {!valid && (
          <button class="form-field" type="submit">
            Register
          </button>
        )}
      </form>
    </div>
  );
}
